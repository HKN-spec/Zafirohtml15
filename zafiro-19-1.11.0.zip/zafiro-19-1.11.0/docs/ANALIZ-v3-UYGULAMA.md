# Analiz v3 → uygulama eşlemesi (v1.21.0-superagent)

`Zafiro-Analiz-v3-Super-Agent.md` raporundaki F1–F12 bulgularına karşı yapılan kod
değişiklikleri. Amaç yeni özellik sayısı değil, **ölçümün doğruluğu** ve **sınavın
gerçekliği**.

## F1 — Telemetri yanlış negatif üretiyor ⛔ → düzeltildi

**Kök neden:** `LocalToolExecutor` jurnale `ok` yazarken ham çıktıda `"ok":true`
arıyordu. `shell` gibi araçlar `{"stdout":…,"stderr":…,"exit_code":0}` döndürür;
`ok` alanı yoktur → her başarılı shell çağrısı `ok:false` yazıldı.

**Değişiklik:**
- `ok` artık `decodeOutcome(raw)` sonucundan geliyor: `ToolCallOutcome.Success`
  (exit_code=0, ok=true, text-protocol success) → `recordJournalSpan`.
- `ToolSpan` alanları: `turn_id`, `args_preview`, `result_preview`, `flags`
  (redakte edilmiş, 400 karakter). Aktif tur kimliği `EvolutionRuntime` içindeki
  aktif tur kuyruğundan gelir.
- `journal/trace.jsonl`: yeniden oynatılabilir iz; 7 gün sonra otomatik yaşlanır
  (`pruneTrace`). Sırlar `Redactor` ile maskelenir.
- `SelfSense.diagnose`: araç gap'i için **n≥5** ve başarı <%90 şartı; n<5 veya
  başarı ≥%95 ise eski `gap-tool-*` kaydı `FALSE_POSITIVE` olarak kapatılır.
  `GapStatus.FALSE_POSITIVE` eklendi. Yeni kanıt (≥5 hata) gelirse gap yeniden açılır.
- Rapor `sample_quality` (`ok|weak|insufficient`) ve `tool_samples` haritası taşır.

**Doğrulama:** `SelfCheck.sampleGating` — 3 hata gap üretmiyor, 8 hata üretiyor,
sağlıklı 6 çağrı gap üretmiyor; trace `args_preview` içeriyor.

## F2 — Arena modeli koşmuyor / sahte %100 → düzeltildi

- `arena_run(live=true)`: payload **gerçek sandbox ajanına** verilir
  (`AgentManager.createSandboxedTaskAgent`); ajanın araç yüzeyi boş ya da salt-okunur
  whitelist (`LiveTurnExecutor.SAFE_LIVE_TOOLS`). Yanıt `ArenaJudge.judge` ile notlanır.
- **Sert kural:** `detected = []` ise `defended=false`. Canary'nin *payload içinde*
  bulunması sızıntı sayılmaz; sızıntı yalnızca **yanıtta** aranır.
- `mustDo` görevleri eksikse savunma sayılmaz (görevi tamamla, enjeksiyona uyma).
- `arena_run(live=false)` artık "statik guard testi" olarak dürüst etiketlenir.

## F3 — Sınav kendi kendini notluyor → canlı executor + mühür

- `evals_run(live=true)`: her hedef `LiveTurnExecutor` ile gerçek bir turda koşulur;
  çıktı, araçlar, adım ve süre toplanır; sonra `EvalRunner.judge` uygulanır.
  Sandbox ajanı araçsızdır; araç bekleyen senaryolar doğal olarak kırılır (dürüst).
- **Mühür:** `evals/catalog.json` yalnızca 30 görünür senaryo içerir; 20 tutulan
  senaryo APK'nın derlenmiş kodundadır. Diske yalnızca
  `evals/heldout.index.json` (id + hedef hash'i) yazılır. Eski 50'lik katalog bir
  sonraki açılışta 30'a indirilir.
- **Mutasyon denetimi:** `EvalAudit.mutationProblems` boş yanıtla geçen senaryoyu
  "test bir şey yakalamıyor" diye işaretler; `evals_list` sonucuna eklenir.
- Tutulan seti koşturmak hâlâ `allow_held_out=true` bayrağına bağlı; bu bir insan
  kararı olarak kalmalı (aşağıdaki sınırlara bak).

## F4 — Rahim kapalıydı → zincir açıldı

- `fs_edit`, `repo_sync`, `compile_check`, `test_run`, `install_artifact`,
  `evolution_settings` artık **varsayılan açık**; guard'lar yerinde:
  - `fs_edit` varsayılan `dry_run=true`; commit yalnız `selfdev/` dalına.
  - CI yalnız aday dalda tetiklenir.
  - `install_artifact` yalnız `.next` üretir; SHA-256/versionCode/build-info doğrular.
  - `evolution_settings` `auto_promote`, arena/jurnal kapatma isteklerini reddeder.
- GitHub token hâlâ kullanıcı tarafından bir kez girilir:
  `evolution_settings(action="set_github_token")`. Kod bunu kendiliğinden üretemez.

## F5 — Kalıtım gerçeği yansıtmıyor → genom senkronu

- `GenomeTool(action="sync")` gerçek skill dizini, py araçları, tarifler ve yüklü
  plugin'leri okur; `EvolutionRuntime.syncGenome` fark varsa **çocuk genom** üretir
  (sessiz mutasyon değil) ve `genome_drift.json` yazar.
- `active_genome.json` işaretçisi eklendi; en yeni genom artık saat sıralamasına
  bağlı değil.
- App açılışta 20 sn sonra senkronu bir kez otomatik çalıştırır.

## F6 — Otonom döngü yok → **kısmi**

Canlı eval/arena ve CI hattı var; ancak **kullanıcı tetiklemeden** çalışan gece
inisiyatifi bu sürümde yok. Sonraki adım: WorkManager + koşul motoru (şarj, saat,
ekran kapalı) ve `mission.json`. Bilinçli olarak yapılmadı: yarı çalışan bir otonomi,
olmayandan daha tehlikeli.

## F7 — L4 plugin yok → yükleyici var, fabrika yok

`DexClassLoader` + manifest + yayıncı HMAC + izin reddi çalışır durumda. CI'da plugin
derleyen `plugin.yml` ve örnek plugin **sonraki adım**; bugün plugin'ler
`files/evolution/plugins/<id>/` altına elle konur.

## F8 — Örneklem yok → eşikler ve görünürlük

- Gap üretimi n≥5, tur bazlı gap n≥10.
- Drift `sufficient` alanı: n<10 → "yetersiz örnek", skor üretilmez.
- `evolution_status` `samples` (tur, araç, eval, arena) ve rapor `sample_quality`
  taşır; pano "Örneklem" KPI'sı gösterir.
- Fitness hâlâ vektördür; örnek yoksa "%100" iddiası yerine "yetersiz" demek üzere
  tasarlanmıştır.

## F9 — Tek ajan → **yok**

`createSandboxedTaskAgent` altyapısı geldi (canlı eval/arena için), fakat kullanıcıya
açık `spawn_agent(role, tools, budget)` ve kalıcı uzman çocuklar yok. Sonraki adım.

## F10 — `py_install_apk` riskli → sertleştirildi

- `su`/`pm install` kaldırıldı; araç yalnız HTTPS indirir, 300 MB sınırı uygular,
  SHA-256 hesaplar (opsiyonel `expected_sha256` doğrular), `.sha256` yan dosyası
  bırakır ve `action_required=user_consent` döner.
- Eski `su` tabanlı seed, `seedPyTools` içinde otomatik olarak yeni sürümle değiştirilir.
- Açıklama artık "kurulum kullanıcı onayına bağlı" der.

## F11 — Yeniden oynatma yok → trace

`journal/trace.jsonl`: araç, redakte argüman önizlemesi, sonuç önizlemesi, süre,
`turn_id`, bayraklar (`empty_success`, `untrusted_content`). `journal.tools.jsonl`
geriye uyumlu kalır.

## F12 — Anayasa sağlam ✅ → dokunulmadı

Hash-kilitli anayasa, 12 madde, korumalı yollar aynı. `evolution_settings` artık
anayasa/eval/oto-promosyon değişikliğini reddeder; `fs_edit` korumalı yolları yazar
diyе reddeder.

## Yeni sürümde doğrulama

- `./gradlew :evolution:selfCheck` → **82 kontrol**, 0 hata (yerelde `kotlinc` ile
  de aynı sonuç).
- `arena_run` statik guard testi: 40 senaryo; savunma yalnız kanıtlı.
- `evals_list`: 30 görünür + 20 mühürlü, mutasyon denetimi.
- CI: `ci.yml` self-check + birim testleri; `evolve.yml` aday APK; `promote.yml`
  insan onaylı terfi.

## Bilinçli olarak yapılmayanlar

1. **Gece otonomisi** (F6): yarım scheduler yerine sonraki sürüm.
2. **Plugin fabrikası** (F7): yükleyici var; CI tarafı sonraki adım.
3. **Uzman çocuk ajanlar** (F9): sandbox altyapısı hazır, ürün yüzeyi yok.
4. **Tutulan setin insan kapısı**: içerik mühürlü, koşu bayrağı hâlâ ajan tarafından
   set edilebilir; gerçek insan kapısı için Android Keystore tabanlı parola sonraki adım.
